import cv2
from deepface import DeepFace
import os
import time
import pandas as pd
from datetime import datetime

# Inisialisasi kamera dan face detector
cam = cv2.VideoCapture(0)
face_detector = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# Jeda waktu deteksi (per orang)
DETECTION_COOLDOWN = 5  # detik
last_detected_time = {}
detected_names = set()

# Data absensi (disimpan sementara dalam list)
absensi_data = []

print("Tekan Q untuk keluar")

while True:
    ret, frame = cam.read()
    if not ret:
        break

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_detector.detectMultiScale(gray, 1.3, 5)
    current_time = time.time()

    for (x, y, w, h) in faces:
        face_crop = frame[y:y+h, x:x+w]

        try:
            result = DeepFace.find(img_path=face_crop, db_path="dataset", enforce_detection=False)

            if len(result) > 0 and len(result[0]) > 0:
                identity_path = result[0].iloc[0]["identity"]
                identity_name = os.path.basename(identity_path).split('.')[0]

                last_time = last_detected_time.get(identity_name, 0)
                if current_time - last_time >= DETECTION_COOLDOWN:
                    last_detected_time[identity_name] = current_time

                    if identity_name not in detected_names:
                        detected_names.add(identity_name)

                        waktu = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                        absensi_data.append({
                            'Nama': identity_name,
                            'Waktu': waktu,
                            'Status': 'Hadir'
                        })

                        print(f"[INFO] {identity_name} terdeteksi pada {waktu}!")

                    label = f"Dikenali: {identity_name}"
                else:
                    label = "Sudah dideteksi"
            else:
                label = "Tidak dikenali"

        except Exception as e:
            label = "Error pencocokan"
            print("Error:", e)

        cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)
        cv2.putText(frame, label, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

    cv2.imshow("Absensi Otomatis", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Setelah keluar, simpan ke Excel
if absensi_data:
    df = pd.DataFrame(absensi_data)
    filename = f"absensi_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    df.to_excel(filename, index=False)
    print(f"\n✅ Data absensi berhasil disimpan ke file: {filename}")
else:
    print("\n⚠️ Tidak ada wajah yang berhasil dikenali. File tidak dibuat.")

# Cleanup
cam.release()
cv2.destroyAllWindows()
